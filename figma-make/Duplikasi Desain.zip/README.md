
  # Duplikasi Desain

  This is a code bundle for Duplikasi Desain. The original project is available at https://www.figma.com/design/t61XAC07x714b7l3tEmQFC/Duplikasi-Desain.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  