import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Toaster } from "./components/ui/sonner";
import { CoverSection } from "./components/CoverSection";
import { HeroSection } from "./components/HeroSection";
import { QuoteSection } from "./components/QuoteSection";
import { CoupleSection } from "./components/CoupleSection";
import { EventSection } from "./components/EventSection";
import { LoveStorySection } from "./components/LoveStorySection";
import { GiftSection } from "./components/GiftSection";
import { RSVPSection } from "./components/RSVPSection";
import { GallerySection } from "./components/GallerySection";
import { ClosingSection } from "./components/ClosingSection";
import { FloatingButtons } from "./components/FloatingButtons";

export default function App() {
  const [isInvitationOpened, setIsInvitationOpened] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  const handleOpenInvitation = () => {
    setIsInvitationOpened(true);
    // Scroll to hero section smoothly
    setTimeout(() => {
      window.scrollTo({ top: window.innerHeight, behavior: 'smooth' });
    }, 300);
  };

  if (isLoading) {
    return <LoadingScreen />;
  }

  return (
    <div className="relative overflow-x-hidden bg-gray-400 min-h-screen">
      {/* Desktop Background */}
      <div className="fixed inset-0 bg-gradient-to-br from-gray-300 to-gray-500 -z-10" />
      
      {/* Mobile Container */}
      <div className="relative w-full max-w-[500px] mx-auto bg-white min-h-screen shadow-2xl">
        {/* Toast Notifications */}
        <Toaster position="top-center" />

        {/* Cover Section - Always visible */}
        <CoverSection onOpenInvitation={handleOpenInvitation} guestName="Nama Tamu" />

        {/* Main Content - Shown after opening invitation */}
        <AnimatePresence>
          {isInvitationOpened && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
            >
              <HeroSection />
              <QuoteSection />
              <CoupleSection />
              <EventSection />
              <LoveStorySection />
              <GiftSection />
              <RSVPSection />
              <GallerySection />
              <ClosingSection />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Floating Buttons */}
        {isInvitationOpened && <FloatingButtons />}
      </div>
    </div>
  );
}

function LoadingScreen() {
  return (
    <div className="fixed inset-0 bg-[#a7a7ab] flex items-center justify-center z-50">
      <div className="text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="mb-4"
        >
          {/* Decorative Loading Animation */}
          <svg width="80" height="80" viewBox="0 0 100 100" className="mx-auto">
            <motion.circle
              cx="50"
              cy="50"
              r="40"
              stroke="#96483E"
              strokeWidth="4"
              fill="none"
              strokeDasharray="251.2"
              animate={{
                strokeDashoffset: [251.2, 0],
                rotate: [0, 360]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "linear"
              }}
            />
          </svg>
        </motion.div>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-[#96483E]"
          style={{ fontFamily: "'Dancing Script', cursive", fontSize: "24px" }}
        >
          Loading...
        </motion.div>
      </div>
    </div>
  );
}
