import { motion } from "motion/react";

interface CoverSectionProps {
  onOpenInvitation: () => void;
  guestName?: string;
}

export function CoverSection({ onOpenInvitation, guestName = "Nama Tamu" }: CoverSectionProps) {
  return (
    <section className="relative min-h-screen flex items-center justify-center bg-[#a7a7ab] overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0" style={{
          backgroundImage: `repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(0,0,0,.05) 10px, rgba(0,0,0,.05) 20px)`
        }} />
      </div>

      {/* Content Container */}
      <div className="relative z-10 max-w-md w-full mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="bg-[#fff1db]/80 backdrop-blur-sm border-2 border-[#96483E] rounded-[20rem] p-8 py-16"
        >
          {/* The Wedding Of */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-center mb-6 text-[#271d1c]"
          >
            The Wedding Of
          </motion.div>

          {/* Bride Name */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5 }}
            className="text-center text-[#96483E] mb-2"
            style={{ fontFamily: "'Playfair Display', serif", fontSize: "60px", lineHeight: "1.1" }}
          >
            Arista
          </motion.div>

          {/* Ampersand */}
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.7 }}
            className="text-center text-[#96483E] mb-2"
            style={{ fontFamily: "'Dancing Script', cursive", fontSize: "24px" }}
          >
            &
          </motion.div>

          {/* Groom Name */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.9 }}
            className="text-center text-[#96483E] mb-8"
            style={{ fontFamily: "'Playfair Display', serif", fontSize: "60px", lineHeight: "1.1" }}
          >
            Andra
          </motion.div>

          {/* Guest Info */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2 }}
            className="text-center mb-3 text-[#271d1c]"
          >
            <div className="mb-2">Kepada Yth;<br />Bapak/Ibu/Saudara/i</div>
            <div className="text-[#96483E] mt-2">
              {guestName}
            </div>
          </motion.div>

          {/* Open Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.5 }}
            className="text-center"
          >
            <button
              onClick={onOpenInvitation}
              className="bg-[#96483E] text-white px-8 py-3 rounded-full hover:bg-[#7d3a32] transition-colors"
            >
              Open Invitation
            </button>
          </motion.div>
        </motion.div>
      </div>

      {/* Decorative Elements */}
      <DecorativeFrames />
    </section>
  );
}

function DecorativeFrames() {
  return (
    <>
      {/* Animated Boat */}
      <motion.div
        animate={{ x: ["0vw", "100vw"] }}
        transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
        className="absolute top-1/2 -translate-y-1/2 pointer-events-none z-0"
        style={{ height: "150px" }}
      >
        <svg viewBox="0 0 200 100" className="h-full w-auto opacity-30">
          <path d="M20,80 L50,50 L150,50 L180,80 Z M60,50 L60,30 L80,10 L100,30 L100,50" 
                fill="#96483E" stroke="#271d1c" strokeWidth="2"/>
          <path d="M70,30 L90,30 M70,40 L90,40" stroke="#271d1c" strokeWidth="1"/>
        </svg>
      </motion.div>
    </>
  );
}
