import { motion } from "motion/react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Calendar } from "lucide-react";

export function HeroSection() {
  const handleSaveDate = () => {
    const eventDetails = {
      text: "Wedding Arista & Andra",
      dates: "20250505/20250505",
      details: "Join us for the wedding celebration of Arista and Andra"
    };
    
    const googleCalendarUrl = `https://calendar.google.com/calendar/u/0/r/eventedit?text=${encodeURIComponent(eventDetails.text)}&dates=${eventDetails.dates}&details=${encodeURIComponent(eventDetails.details)}`;
    window.open(googleCalendarUrl, '_blank');
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center bg-[#a7a7ab] overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0" style={{
          backgroundImage: `repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(0,0,0,.05) 10px, rgba(0,0,0,.05) 20px)`
        }} />
      </div>

      {/* Content Container */}
      <div className="relative z-10 max-w-md w-full mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="bg-[#fff1db]/80 backdrop-blur-sm border-2 border-[#96483E] rounded-[20rem] p-6 pb-12"
        >
          {/* Couple Photo */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="w-full h-[450px] mb-6 border-4 border-[#96483E] overflow-hidden"
            style={{ borderRadius: "20rem 20rem 0 0" }}
          >
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1724812773350-a7d0bf664417?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwd2VkZGluZyUyMGNvdXBsZXxlbnwxfHx8fDE3NjAwODg2MzB8MA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Arista & Andra"
              className="w-full h-full object-cover"
              style={{ borderRadius: "250px 250px 0 0" }}
            />
          </motion.div>

          {/* Wedding Info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="text-center mb-8"
          >
            <div className="text-[#271d1c] mb-2">THE WEDDING OF</div>
            
            <div className="text-[#96483E] mb-2"
                 style={{ fontFamily: "'Playfair Display', serif", fontSize: "40px", lineHeight: "1.2" }}>
              Arista & Andra
            </div>
            
            <div className="text-[#271d1c]" style={{ fontFamily: "'Playfair Display', serif" }}>
              05 . 05 . 25
            </div>

            {/* Save the Date Button */}
            <motion.button
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.6 }}
              onClick={handleSaveDate}
              className="inline-flex items-center gap-2 bg-[#96483E] text-white px-6 py-3 rounded-full hover:bg-[#7d3a32] transition-colors mt-4"
            >
              <Calendar className="w-4 h-4" />
              Save the Date
            </motion.button>
          </motion.div>
        </motion.div>
      </div>

      {/* Decorative Boat Animation */}
      <AnimatedBoat />
    </section>
  );
}

function AnimatedBoat() {
  return (
    <motion.div
      animate={{ x: ["-100vw", "100vw"] }}
      transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
      className="absolute top-1/2 -translate-y-1/2 pointer-events-none z-0"
      style={{ height: "150px" }}
    >
      <svg viewBox="0 0 200 100" className="h-full w-auto opacity-30">
        <path d="M20,80 L50,50 L150,50 L180,80 Z M60,50 L60,30 L80,10 L100,30 L100,50" 
              fill="#96483E" stroke="#271d1c" strokeWidth="2"/>
        <path d="M70,30 L90,30 M70,40 L90,40" stroke="#271d1c" strokeWidth="1"/>
      </svg>
    </motion.div>
  );
}
