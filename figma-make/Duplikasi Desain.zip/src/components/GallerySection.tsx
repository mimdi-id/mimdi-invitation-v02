import { motion } from "motion/react";
import { useState } from "react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { X, ChevronLeft, ChevronRight } from "lucide-react";

const galleryImages = [
  "https://images.unsplash.com/photo-1724812773350-a7d0bf664417?w=800",
  "https://images.unsplash.com/photo-1596026339984-e16bfa013cf7?w=800",
  "https://images.unsplash.com/photo-1758141069056-986f9599adee?w=800",
  "https://images.unsplash.com/photo-1667839419946-f6c6c2bdf332?w=800",
  "https://images.unsplash.com/photo-1672290103417-3cff585ec2c4?w=800",
  "https://images.unsplash.com/photo-1696204868916-cda7380ae72b?w=800"
];

export function GallerySection() {
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const openLightbox = (index: number) => {
    setCurrentImageIndex(index);
    setLightboxOpen(true);
  };

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % galleryImages.length);
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + galleryImages.length) % galleryImages.length);
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center bg-[#a7a7ab] overflow-hidden py-16">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0" style={{
          backgroundImage: `repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(0,0,0,.05) 10px, rgba(0,0,0,.05) 20px)`
        }} />
      </div>

      {/* Content Container */}
      <div className="relative z-10 max-w-md w-full mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="bg-[#fff1db]/80 backdrop-blur-sm border-2 border-[#96483E] rounded-3xl p-8 py-12"
        >
          {/* Title */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-center text-[#96483E] mb-8"
            style={{ fontFamily: "'Dancing Script', cursive", fontSize: "50px", lineHeight: "1" }}
          >
            Gallery
          </motion.div>

          {/* Gallery Grid */}
          <div className="flex flex-wrap -mx-1">
            {galleryImages.map((image, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 * index }}
                className={`p-1 ${index % 3 === 1 ? "w-full sm:w-7/12" : "w-full sm:w-5/12"}`}
                onClick={() => openLightbox(index)}
              >
                <div className="relative h-36 overflow-hidden rounded-lg cursor-pointer hover:opacity-90 transition-opacity">
                  <ImageWithFallback
                    src={image}
                    alt={`Gallery ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Lightbox */}
      {lightboxOpen && (
        <Lightbox
          images={galleryImages}
          currentIndex={currentImageIndex}
          onClose={() => setLightboxOpen(false)}
          onNext={nextImage}
          onPrev={prevImage}
        />
      )}

      {/* Animated Boat */}
      <AnimatedBoat />
    </section>
  );
}

interface LightboxProps {
  images: string[];
  currentIndex: number;
  onClose: () => void;
  onNext: () => void;
  onPrev: () => void;
}

function Lightbox({ images, currentIndex, onClose, onNext, onPrev }: LightboxProps) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center"
      onClick={onClose}
    >
      {/* Close Button */}
      <button
        onClick={onClose}
        className="absolute top-4 right-4 text-white p-2 hover:bg-white/10 rounded-full transition-colors z-10"
      >
        <X className="w-8 h-8" />
      </button>

      {/* Image */}
      <div
        className="relative max-w-4xl max-h-screen p-4"
        onClick={(e) => e.stopPropagation()}
      >
        <ImageWithFallback
          src={images[currentIndex]}
          alt={`Gallery ${currentIndex + 1}`}
          className="max-w-full max-h-[90vh] object-contain rounded-lg"
        />
      </div>

      {/* Navigation */}
      <button
        onClick={(e) => {
          e.stopPropagation();
          onPrev();
        }}
        className="absolute left-4 top-1/2 -translate-y-1/2 text-white p-3 hover:bg-white/10 rounded-full transition-colors"
      >
        <ChevronLeft className="w-8 h-8" />
      </button>

      <button
        onClick={(e) => {
          e.stopPropagation();
          onNext();
        }}
        className="absolute right-4 top-1/2 -translate-y-1/2 text-white p-3 hover:bg-white/10 rounded-full transition-colors"
      >
        <ChevronRight className="w-8 h-8" />
      </button>

      {/* Counter */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-white bg-black/50 px-4 py-2 rounded-full">
        {currentIndex + 1} / {images.length}
      </div>
    </motion.div>
  );
}

function AnimatedBoat() {
  return (
    <motion.div
      animate={{ x: ["-100vw", "100vw"] }}
      transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
      className="absolute top-1/2 -translate-y-1/2 pointer-events-none z-0"
      style={{ height: "150px" }}
    >
      <svg viewBox="0 0 200 100" className="h-full w-auto opacity-30">
        <path d="M20,80 L50,50 L150,50 L180,80 Z M60,50 L60,30 L80,10 L100,30 L100,50" 
              fill="#96483E" stroke="#271d1c" strokeWidth="2"/>
        <path d="M70,30 L90,30 M70,40 L90,40" stroke="#271d1c" strokeWidth="1"/>
      </svg>
    </motion.div>
  );
}
