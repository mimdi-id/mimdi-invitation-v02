import { motion } from "motion/react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function ClosingSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center bg-[#a7a7ab] overflow-hidden py-16">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0" style={{
          backgroundImage: `repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(0,0,0,.05) 10px, rgba(0,0,0,.05) 20px)`
        }} />
      </div>

      {/* Content Container */}
      <div className="relative z-10 max-w-md w-full mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="bg-[#fff1db]/80 backdrop-blur-sm border-2 border-[#96483E] rounded-3xl p-8 py-12"
        >
          {/* Couple Photo */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="w-full max-w-xs h-96 mx-auto mb-6 border-4 border-[#96483E] overflow-hidden rounded-2xl"
          >
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1596026339984-e16bfa013cf7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwY291cGxlJTIwcm9tYW50aWN8ZW58MXx8fHwxNzYwMTM0OTI0fDA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Arista & Andra"
              className="w-full h-full object-cover"
            />
          </motion.div>

          {/* Closing Message */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="text-center"
          >
            <p className="text-[#271d1c] mb-4 leading-relaxed">
              Merupakan suatu kebahagiaan dan kehormatan bagi kami, apabila Bapak/Ibu/Saudara/i, berkenan hadir dan memberikan do'a restu kepada kedua mempelai.
            </p>

            <p className="text-[#271d1c] italic mb-3">
              Hormat Kami Yang Mengundang
            </p>

            <div className="text-[#96483E]"
                 style={{ fontFamily: "'Dancing Script', cursive", fontSize: "32px", lineHeight: "1.2" }}>
              Arista & Andra
            </div>
          </motion.div>

          {/* Watermark */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.6 }}
            className="mt-8 pt-6 border-t border-[#96483E]/30 text-center text-sm text-[#271d1c]/60"
          >
            <p>Created with ❤️ for Arista & Andra</p>
          </motion.div>
        </motion.div>
      </div>

      {/* Animated Boat */}
      <AnimatedBoat />
    </section>
  );
}

function AnimatedBoat() {
  return (
    <motion.div
      animate={{ x: ["-100vw", "100vw"] }}
      transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
      className="absolute top-1/2 -translate-y-1/2 pointer-events-none z-0"
      style={{ height: "150px" }}
    >
      <svg viewBox="0 0 200 100" className="h-full w-auto opacity-30">
        <path d="M20,80 L50,50 L150,50 L180,80 Z M60,50 L60,30 L80,10 L100,30 L100,50" 
              fill="#96483E" stroke="#271d1c" strokeWidth="2"/>
        <path d="M70,30 L90,30 M70,40 L90,40" stroke="#271d1c" strokeWidth="1"/>
      </svg>
    </motion.div>
  );
}
