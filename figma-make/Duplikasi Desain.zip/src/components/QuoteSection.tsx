import { motion } from "motion/react";

export function QuoteSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center bg-[#a7a7ab] overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0" style={{
          backgroundImage: `repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(0,0,0,.05) 10px, rgba(0,0,0,.05) 20px)`
        }} />
      </div>

      {/* Dark Overlay */}
      <div className="absolute inset-0 bg-[#96483E]/80 z-0" />

      {/* Content Container */}
      <div className="relative z-10 max-w-md w-full mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-white"
        >
          {/* Decorative Initials */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="flex items-center justify-center gap-3 mb-8"
          >
            <div style={{ fontFamily: "'Playfair Display', serif", fontSize: "80px", lineHeight: "1" }}>
              A
            </div>
            <div className="w-0.5 h-16 bg-white" />
            <div style={{ fontFamily: "'Playfair Display', serif", fontSize: "80px", lineHeight: "1" }}>
              A
            </div>
          </motion.div>

          {/* Quote */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="text-center mb-4"
          >
            <p className="mb-4 leading-relaxed">
              Dan di antara tanda-tanda (kebesaran)-Nya ialah Dia menciptakan pasangan-pasangan untukmu dari jenismu sendiri, agar kamu cenderung dan merasa tenteram kepadanya, dan Dia menjadikan di antaramu rasa kasih dan sayang. Sungguh, pada yang demikian itu benar-benar terdapat tanda-tanda (kebesaran Allah) bagi kaum yang berpikir.
            </p>
            <div style={{ fontFamily: "'Playfair Display', serif" }}>
              Surah Ar-Rum : 21
            </div>
          </motion.div>
        </motion.div>
      </div>

      {/* Animated Boat */}
      <AnimatedBoat />
    </section>
  );
}

function AnimatedBoat() {
  return (
    <motion.div
      animate={{ x: ["-100vw", "100vw"] }}
      transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
      className="absolute top-1/2 -translate-y-1/2 pointer-events-none z-0"
      style={{ height: "150px" }}
    >
      <svg viewBox="0 0 200 100" className="h-full w-auto opacity-20">
        <path d="M20,80 L50,50 L150,50 L180,80 Z M60,50 L60,30 L80,10 L100,30 L100,50" 
              fill="#ffffff" stroke="#ffffff" strokeWidth="2"/>
        <path d="M70,30 L90,30 M70,40 L90,40" stroke="#ffffff" strokeWidth="1"/>
      </svg>
    </motion.div>
  );
}
