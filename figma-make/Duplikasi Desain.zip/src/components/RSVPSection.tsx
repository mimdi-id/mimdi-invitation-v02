import { motion } from "motion/react";
import { useState, useEffect } from "react";
import { MessageSquare } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Button } from "./ui/button";
import { toast } from "sonner@2.0.3";

export function RSVPSection() {
  const [isOpen, setIsOpen] = useState(false);
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  useEffect(() => {
    const targetDate = new Date("2025-05-05T08:00:00").getTime();

    const interval = setInterval(() => {
      const now = new Date().getTime();
      const difference = targetDate - now;

      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((difference % (1000 * 60)) / 1000)
        });
      }
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center bg-[#a7a7ab] overflow-hidden py-16">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0" style={{
          backgroundImage: `repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(0,0,0,.05) 10px, rgba(0,0,0,.05) 20px)`
        }} />
      </div>

      {/* Content Container */}
      <div className="relative z-10 max-w-md w-full mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="bg-[#fff1db]/80 backdrop-blur-sm border-2 border-[#96483E] rounded-3xl p-8 py-12"
        >
          {/* Title */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-center text-[#96483E] mb-8"
            style={{ fontFamily: "'Dancing Script', cursive", fontSize: "50px", lineHeight: "1" }}
          >
            RSVP
          </motion.div>

          {/* Countdown */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
            className="mb-8"
          >
            <div className="grid grid-cols-4 gap-3 max-w-sm mx-auto">
              <CountdownItem value={timeLeft.days} label="Hari" />
              <CountdownItem value={timeLeft.hours} label="Jam" />
              <CountdownItem value={timeLeft.minutes} label="Menit" />
              <CountdownItem value={timeLeft.seconds} label="Detik" />
            </div>
          </motion.div>

          {/* Description */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="text-center text-[#271d1c] mb-6"
          >
            <p>
              Sampaikan do'a atau salam<br />
              kepada pengantin dan konfirmasi<br />
              kehadiran.
            </p>
          </motion.div>

          {/* RSVP Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.5 }}
            className="text-center"
          >
            <button
              onClick={() => setIsOpen(true)}
              className="inline-flex items-center gap-2 bg-[#96483E] text-white px-8 py-3 rounded-full hover:bg-[#7d3a32] transition-colors"
            >
              <MessageSquare className="w-5 h-5" />
              Kirim Ucapan RSVP
            </button>
          </motion.div>
        </motion.div>
      </div>

      {/* RSVP Modal */}
      <RSVPModal isOpen={isOpen} onClose={() => setIsOpen(false)} />

      {/* Animated Boat */}
      <AnimatedBoat />
    </section>
  );
}

interface CountdownItemProps {
  value: number;
  label: string;
}

function CountdownItem({ value, label }: CountdownItemProps) {
  return (
    <div className="bg-white/30 rounded-lg p-3 text-center">
      <div className="text-[#96483E] mb-1" style={{ fontSize: "28px" }}>
        {String(value).padStart(2, "0")}
      </div>
      <div className="text-[#271d1c] text-sm">{label}</div>
    </div>
  );
}

interface RSVPModalProps {
  isOpen: boolean;
  onClose: () => void;
}

function RSVPModal({ isOpen, onClose }: RSVPModalProps) {
  const [formData, setFormData] = useState({
    name: "",
    attendance: "yes",
    guestCount: "1",
    message: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Terima kasih! Ucapan Anda telah terkirim.");
    onClose();
    setFormData({ name: "", attendance: "yes", guestCount: "1", message: "" });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-[#fff1db] border-2 border-[#96483E] max-w-md">
        <DialogHeader>
          <DialogTitle className="text-[#96483E] text-center" style={{ fontFamily: "'Playfair Display', serif" }}>
            Form RSVP
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-[#271d1c] mb-2">Nama</label>
            <Input
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="Nama Anda"
              className="bg-white/50 border-[#96483E]"
            />
          </div>

          <div>
            <label className="block text-[#271d1c] mb-2">Kehadiran</label>
            <select
              value={formData.attendance}
              onChange={(e) => setFormData({ ...formData, attendance: e.target.value })}
              className="w-full p-2 rounded-md bg-white/50 border border-[#96483E] text-[#271d1c]"
            >
              <option value="yes">Hadir</option>
              <option value="no">Tidak Hadir</option>
            </select>
          </div>

          {formData.attendance === "yes" && (
            <div>
              <label className="block text-[#271d1c] mb-2">Jumlah Tamu</label>
              <Input
                type="number"
                min="1"
                max="5"
                value={formData.guestCount}
                onChange={(e) => setFormData({ ...formData, guestCount: e.target.value })}
                className="bg-white/50 border-[#96483E]"
              />
            </div>
          )}

          <div>
            <label className="block text-[#271d1c] mb-2">Ucapan & Doa</label>
            <Textarea
              required
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              placeholder="Tulis ucapan atau doa untuk pengantin..."
              rows={4}
              className="bg-white/50 border-[#96483E]"
            />
          </div>

          <Button
            type="submit"
            className="w-full bg-[#96483E] hover:bg-[#7d3a32] text-white rounded-full"
          >
            Kirim
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function AnimatedBoat() {
  return (
    <motion.div
      animate={{ x: ["-100vw", "100vw"] }}
      transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
      className="absolute top-1/2 -translate-y-1/2 pointer-events-none z-0"
      style={{ height: "150px" }}
    >
      <svg viewBox="0 0 200 100" className="h-full w-auto opacity-30">
        <path d="M20,80 L50,50 L150,50 L180,80 Z M60,50 L60,30 L80,10 L100,30 L100,50" 
              fill="#96483E" stroke="#271d1c" strokeWidth="2"/>
        <path d="M70,30 L90,30 M70,40 L90,40" stroke="#271d1c" strokeWidth="1"/>
      </svg>
    </motion.div>
  );
}
