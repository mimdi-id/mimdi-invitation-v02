import { motion } from "motion/react";

export function LoveStorySection() {
  const stories = [
    {
      year: "2017",
      title: "Awal Pertemuan",
      description: "Masa Sekolah Dasar mempertemukan kita, semesta pun menempatkan kita di tempat yang sama. Meski begitu, kita tetaplah orang asing yang tak saling mengenal ataupun dekat. Seiring berjalannya waktu, sebuah pertemuan tak sengaja mempertemukan kita, membuat keanehan berubah menjadi cinta, rindu, dan kegelisahan. Tak pernah kita duga akan ada percikan asmara di antara kita."
    },
    {
      year: "2018",
      title: "Relationship",
      description: "10 Maret 2018 kami mengikat janji sebagai sepasang kekasih."
    },
    {
      year: "2023",
      title: "Engagement",
      description: "3 September 2023, dengan tujuan membawa hubungan ini ke jenjang yang lebih serius, kami melangsungkan prosesi lamaran, dimana kami pertemukan kedua keluarga kami dalam balutan acara pertukaran cincin yang suci dan suasana kekeluargaan yang hangat."
    },
    {
      year: "2025",
      title: "Married",
      description: "Rencana indah Sang Pencipta tak terduga oleh manusia, bukti nyata bahwa kami bisa bersama. Setelah 7 tahun menjalin hubungan, 5 Mei 2025 kelak, InsyaAllah kami akan mengucapkan janji suci pernikahan kami."
    }
  ];

  return (
    <section className="relative min-h-screen flex items-center justify-center bg-[#a7a7ab] overflow-hidden py-16">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0" style={{
          backgroundImage: `repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(0,0,0,.05) 10px, rgba(0,0,0,.05) 20px)`
        }} />
      </div>

      {/* Content Container */}
      <div className="relative z-10 max-w-md w-full mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="bg-[#fff1db]/80 backdrop-blur-sm border-2 border-[#96483E] rounded-[20rem] rounded-b-none p-6 pb-12 pt-16"
        >
          {/* Title */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-center text-[#96483E] mb-8"
            style={{ fontFamily: "'Dancing Script', cursive", fontSize: "60px", lineHeight: "1" }}
          >
            Love Story
          </motion.div>

          {/* Timeline */}
          <div className="space-y-6">
            {stories.map((story, index) => (
              <StoryItem
                key={index}
                year={story.year}
                title={story.title}
                description={story.description}
                delay={0.3 + index * 0.1}
              />
            ))}
          </div>
        </motion.div>
      </div>

      {/* Animated Boat */}
      <AnimatedBoat />
    </section>
  );
}

interface StoryItemProps {
  year: string;
  title: string;
  description: string;
  delay: number;
}

function StoryItem({ year, title, description, delay }: StoryItemProps) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ delay }}
      className="relative pl-8 border-l-2 border-[#96483E]"
    >
      {/* Timeline Dot */}
      <div className="absolute -left-[9px] top-0 w-4 h-4 bg-[#96483E] rounded-full" />
      
      {/* Content */}
      <div className="text-[#271d1c]">
        <div className="text-[#96483E] mb-1">
          {title} ({year})
        </div>
        <p className="leading-relaxed">{description}</p>
      </div>
    </motion.div>
  );
}

function AnimatedBoat() {
  return (
    <motion.div
      animate={{ x: ["-100vw", "100vw"] }}
      transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
      className="absolute top-1/2 -translate-y-1/2 pointer-events-none z-0"
      style={{ height: "150px" }}
    >
      <svg viewBox="0 0 200 100" className="h-full w-auto opacity-30">
        <path d="M20,80 L50,50 L150,50 L180,80 Z M60,50 L60,30 L80,10 L100,30 L100,50" 
              fill="#96483E" stroke="#271d1c" strokeWidth="2"/>
        <path d="M70,30 L90,30 M70,40 L90,40" stroke="#271d1c" strokeWidth="1"/>
      </svg>
    </motion.div>
  );
}
