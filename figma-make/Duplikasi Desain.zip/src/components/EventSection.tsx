import { motion } from "motion/react";
import { MapPin } from "lucide-react";

export function EventSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center bg-[#a7a7ab] overflow-hidden py-16">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0" style={{
          backgroundImage: `repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(0,0,0,.05) 10px, rgba(0,0,0,.05) 20px)`
        }} />
      </div>

      {/* Content Container */}
      <div className="relative z-10 max-w-md w-full mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="bg-[#fff1db]/80 backdrop-blur-sm border-2 border-[#96483E] rounded-3xl p-8 py-12"
        >
          {/* Akad Nikah */}
          <EventItem
            title="Akad Nikah"
            date="Minggu, 25 Mei 2025"
            time="Pukul 08.00 WIB"
            venue="Gedung Serba Guna"
            address="Jl. Mujair Raya, Rumbai"
            mapUrl="https://maps.app.goo.gl/o8UQFMJ13n6c8gW36"
            delay={0.2}
          />

          {/* Divider */}
          <div className="h-12" />

          {/* Resepsi */}
          <EventItem
            title="Resepsi"
            date="Minggu, 25 Mei 2025"
            time="Pukul 11.00 - 14.00 WIB"
            venue="Gedung Serba Guna"
            address="Jl. Mujair Raya, Rumbai"
            mapUrl="https://maps.app.goo.gl/o8UQFMJ13n6c8gW36"
            delay={0.4}
          />
        </motion.div>
      </div>

      {/* Animated Boat */}
      <AnimatedBoat />
    </section>
  );
}

interface EventItemProps {
  title: string;
  date: string;
  time: string;
  venue: string;
  address: string;
  mapUrl: string;
  delay: number;
}

function EventItem({ title, date, time, venue, address, mapUrl, delay }: EventItemProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay }}
      className="text-center"
    >
      {/* Decorative Icon */}
      <div className="flex justify-center mb-4">
        <svg width="50" height="50" viewBox="0 0 50 50" fill="none" className="text-[#96483E]">
          <circle cx="25" cy="25" r="20" stroke="currentColor" strokeWidth="2" fill="none"/>
          <path d="M25 15 L30 20 L25 35 L20 20 Z" fill="currentColor"/>
        </svg>
      </div>

      {/* Title */}
      <div className="text-[#96483E] mb-4"
           style={{ fontFamily: "'Dancing Script', cursive", fontSize: "32px", lineHeight: "1.2" }}>
        {title}
      </div>

      {/* Event Details */}
      <div className="mb-4 text-[#271d1c]">
        <div className="mb-1" style={{ fontFamily: "'Playfair Display', serif", fontSize: "24px" }}>
          {date}
        </div>
        <div className="mb-1">{time}</div>
        <div>{venue}</div>
        <div className="text-sm opacity-75">{address}</div>
      </div>

      {/* Map Button */}
      <a
        href={mapUrl}
        target="_blank"
        rel="nofollow noreferrer noopener"
        className="inline-flex items-center gap-2 bg-[#96483E] text-white px-6 py-2 rounded-full hover:bg-[#7d3a32] transition-colors"
      >
        <MapPin className="w-4 h-4" />
        Open Google Maps
      </a>
    </motion.div>
  );
}

function AnimatedBoat() {
  return (
    <motion.div
      animate={{ x: ["-100vw", "100vw"] }}
      transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
      className="absolute top-1/2 -translate-y-1/2 pointer-events-none z-0"
      style={{ height: "150px" }}
    >
      <svg viewBox="0 0 200 100" className="h-full w-auto opacity-30">
        <path d="M20,80 L50,50 L150,50 L180,80 Z M60,50 L60,30 L80,10 L100,30 L100,50" 
              fill="#96483E" stroke="#271d1c" strokeWidth="2"/>
        <path d="M70,30 L90,30 M70,40 L90,40" stroke="#271d1c" strokeWidth="1"/>
      </svg>
    </motion.div>
  );
}
