import { motion } from "motion/react";
import { Gift, MapPin, Copy, Check } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner@2.0.3";

export function GiftSection() {
  const [activeTab, setActiveTab] = useState<"cashless" | "gift">("cashless");
  const [copiedAccount, setCopiedAccount] = useState<string | null>(null);

  const copyToClipboard = (text: string, accountName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedAccount(accountName);
    toast.success(`Nomor rekening ${accountName} telah disalin`);
    setTimeout(() => setCopiedAccount(null), 2000);
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center bg-[#a7a7ab] overflow-hidden py-16">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0" style={{
          backgroundImage: `repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(0,0,0,.05) 10px, rgba(0,0,0,.05) 20px)`
        }} />
      </div>

      {/* Content Container */}
      <div className="relative z-10 max-w-md w-full mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="bg-[#fff1db]/80 backdrop-blur-sm border-2 border-[#96483E] rounded-3xl p-8 py-12"
        >
          {/* Title */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-center mb-6"
          >
            <div className="text-[#96483E] mb-3"
                 style={{ fontFamily: "'Dancing Script', cursive", fontSize: "50px", lineHeight: "1" }}>
              Wedding Gift
            </div>
            <p className="text-[#271d1c]">
              Terima kasih telah menambah semangat kegembiraan pernikahan kami dengan kehadiran dan hadiah indah Anda.
            </p>
          </motion.div>

          {/* Tabs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
            className="flex gap-2 mb-6"
          >
            <button
              onClick={() => setActiveTab("cashless")}
              className={`flex-1 py-2 px-4 rounded-full transition-colors ${
                activeTab === "cashless"
                  ? "bg-[#96483E] text-white"
                  : "bg-white/50 text-[#271d1c] hover:bg-white/70"
              }`}
            >
              Cashless
            </button>
            <button
              onClick={() => setActiveTab("gift")}
              className={`flex-1 py-2 px-4 rounded-full transition-colors ${
                activeTab === "gift"
                  ? "bg-[#96483E] text-white"
                  : "bg-white/50 text-[#271d1c] hover:bg-white/70"
              }`}
            >
              Kirim Kado
            </button>
          </motion.div>

          {/* Content */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            {activeTab === "cashless" ? (
              <div className="space-y-4">
                <BankAccount
                  bank="BCA"
                  accountNumber="1234567890"
                  accountName="Arista Maulidiyah"
                  onCopy={copyToClipboard}
                  isCopied={copiedAccount === "BCA - Arista"}
                />
                <BankAccount
                  bank="Mandiri"
                  accountNumber="0987654321"
                  accountName="Andra Setiawan"
                  onCopy={copyToClipboard}
                  isCopied={copiedAccount === "Mandiri - Andra"}
                />
              </div>
            ) : (
              <div className="bg-white/30 rounded-2xl p-6 text-center">
                <Gift className="w-12 h-12 text-[#96483E] mx-auto mb-4" />
                <div className="text-[#96483E] mb-2">Kirim Kado</div>
                <p className="text-[#271d1c] mb-4">
                  Anda dapat mengirim kado ke:<br />
                  <span className="inline-block mt-2">
                    Jl. Wildan Sari 1 No 11<br />
                    Banjarmasin Barat 70119
                  </span>
                </p>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText("Jl. Wildan Sari 1 No 11, Banjarmasin Barat 70119");
                    toast.success("Alamat telah disalin");
                  }}
                  className="inline-flex items-center gap-2 bg-[#96483E] text-white px-6 py-2 rounded-full hover:bg-[#7d3a32] transition-colors"
                >
                  <Copy className="w-4 h-4" />
                  Salin Alamat
                </button>
              </div>
            )}
          </motion.div>
        </motion.div>
      </div>

      {/* Animated Boat */}
      <AnimatedBoat />
    </section>
  );
}

interface BankAccountProps {
  bank: string;
  accountNumber: string;
  accountName: string;
  onCopy: (text: string, name: string) => void;
  isCopied: boolean;
}

function BankAccount({ bank, accountNumber, accountName, onCopy, isCopied }: BankAccountProps) {
  return (
    <div className="bg-white/30 rounded-2xl p-4 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <div className="w-16 h-10 bg-white rounded flex items-center justify-center">
          <span className="text-[#96483E]">{bank}</span>
        </div>
        <div>
          <div className="text-[#271d1c]">{accountNumber}</div>
          <div className="text-sm text-[#271d1c]/70">{accountName}</div>
        </div>
      </div>
      <button
        onClick={() => onCopy(accountNumber, `${bank} - ${accountName.split(" ")[0]}`)}
        className="p-2 hover:bg-white/30 rounded-full transition-colors"
      >
        {isCopied ? (
          <Check className="w-5 h-5 text-green-600" />
        ) : (
          <Copy className="w-5 h-5 text-[#96483E]" />
        )}
      </button>
    </div>
  );
}

function AnimatedBoat() {
  return (
    <motion.div
      animate={{ x: ["-100vw", "100vw"] }}
      transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
      className="absolute top-1/2 -translate-y-1/2 pointer-events-none z-0"
      style={{ height: "150px" }}
    >
      <svg viewBox="0 0 200 100" className="h-full w-auto opacity-30">
        <path d="M20,80 L50,50 L150,50 L180,80 Z M60,50 L60,30 L80,10 L100,30 L100,50" 
              fill="#96483E" stroke="#271d1c" strokeWidth="2"/>
        <path d="M70,30 L90,30 M70,40 L90,40" stroke="#271d1c" strokeWidth="1"/>
      </svg>
    </motion.div>
  );
}
