'use client';

import { useState } from 'react';
import { Button } from './components/ui/button';
import { Input } from './components/ui/input';
import { Label } from './components/ui/label';
import { Switch } from './components/ui/switch';
import { Textarea } from './components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Badge } from './components/ui/badge';
import { Separator } from './components/ui/separator';
import { 
  Heart, 
  Users, 
  Calendar, 
  Image as ImageIcon, 
  Music, 
  Copy, 
  Eye,
  Trash2,
  Upload,
  Share2,
  ExternalLink,
  MessageSquare,
  Gift,
  Quote,
  Video,
  MapPin,
  ChevronLeft,
  GripVertical,
  Settings,
  Sparkles
} from 'lucide-react';

// Mock data untuk demo
const mockInvitation = {
  id: '1',
  title: 'Imran & Wati',
  slug: 'imran-dan-wati',
  status: 'PUBLISHED',
  coverImageUrl: 'https://images.unsplash.com/photo-1519741497674-611481863552?w=400&h=600&fit=crop',
  viewCount: 142,
  rsvpCount: 23,
  wishCount: 45,
  createdAt: '2025-10-01',
  packageType: 'Premium',
  expiryDate: '2025-12-31',
  details: {
    bride: { name: 'Wati', father: 'Bapak Wati', mother: 'Ibu Wati' },
    groom: { name: 'Imran', father: 'Bapak Imran', mother: 'Ibu Imran' },
    events: [
      { name: 'Akad Nikah', date: '2025-10-01T10:00', location: 'Kadikdawara' }
    ],
    story: [{ title: 'Pertemuan Pertama', content: 'Kami bertemu...' }],
    gifts: [],
    invitedBy: [''],
    quote: '',
    musicUrl: '',
    videoUrl: '',
  }
};

type InvitationDetails = {
  bride: { name: string; father: string; mother: string };
  groom: { name: string; father: string; mother: string };
  events: Array<{ name: string; date: string; location: string }>;
  story?: Array<{ title: string; content: string }>;
  gifts?: Array<{ type: 'Bank' | 'E-Wallet'; name: string; accountNumber: string; accountHolder: string }>;
  invitedBy?: string[];
  quote?: string;
  musicUrl?: string;
  videoUrl?: string;
};

const sectionsList = [
  { id: 'mempelai', label: 'Data Mempelai', icon: Users, color: 'bg-blue-500' },
  { id: 'acara', label: 'Jadwal Acara', icon: Calendar, color: 'bg-purple-500' },
  { id: 'story', label: 'Cerita Cinta', icon: Heart, color: 'bg-pink-500' },
  { id: 'gallery', label: 'Galeri Foto', icon: ImageIcon, color: 'bg-green-500' },
  { id: 'video', label: 'Video', icon: Video, color: 'bg-red-500' },
  { id: 'lokasi', label: 'Lokasi & Maps', icon: MapPin, color: 'bg-orange-500' },
  { id: 'gift', label: 'Amplop Digital', icon: Gift, color: 'bg-yellow-500' },
  { id: 'quote', label: 'Quote & Doa', icon: Quote, color: 'bg-indigo-500' },
  { id: 'musik', label: 'Musik Latar', icon: Music, color: 'bg-teal-500' },
];

export default function App() {
  const [invitation] = useState(mockInvitation);
  const [activeTab, setActiveTab] = useState('konten');
  const [details, setDetails] = useState<Partial<InvitationDetails>>(mockInvitation.details);
  const [isPublished, setIsPublished] = useState(invitation.status === 'PUBLISHED');
  const [sections, setSections] = useState(
    sectionsList.map(s => ({ ...s, enabled: true }))
  );
  
  const fullInvitationLink = `https://mimdi.test/u/${invitation.slug}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(fullInvitationLink);
    alert('Link berhasil disalin!');
  };

  const handleSaveChanges = () => {
    alert('Perubahan berhasil disimpan!');
  };

  const handleToggleSection = (id: string) => {
    setSections(prev => prev.map(s => 
      s.id === id ? { ...s, enabled: !s.enabled } : s
    ));
  };

  const handleDetailChange = (field: keyof InvitationDetails, value: any) => {
    setDetails(prev => ({ ...prev, [field]: value }));
  };

  const handleNestedChange = (part: keyof InvitationDetails, index: number, field: string, value: any) => {
    setDetails(prev => {
      const list = (prev[part] as any[] | undefined) || [];
      const newList = [...list];
      newList[index] = { ...newList[index], [field]: value };
      return { ...prev, [part]: newList };
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-50 shadow-sm">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon">
                <ChevronLeft className="h-5 w-5" />
              </Button>
              <div className="flex items-center gap-2">
                <div className="bg-gradient-to-br from-red-500 to-pink-500 p-2 rounded-lg">
                  <Heart className="h-4 w-4 text-white fill-white" />
                </div>
                <div>
                  <h1 className="font-semibold">{invitation.title}</h1>
                  <p className="text-xs text-muted-foreground">
                    {invitation.packageType} • Aktif hingga {new Date(invitation.expiryDate).toLocaleDateString('id-ID')}
                  </p>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant={isPublished ? "default" : "secondary"} className="hidden sm:flex">
                {isPublished ? 'Published' : 'Draft'}
              </Badge>
              <Switch checked={isPublished} onCheckedChange={setIsPublished} />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6 max-w-6xl">
        {/* Info Card */}
        <Card className="mb-6 overflow-hidden">
          <CardContent className="p-4 md:p-0">
            <div className="flex flex-col md:flex-row">
              {/* Cover Image */}
              <div className="flex-shrink-0 w-full md:w-56 md:p-4">
                <div className="aspect-[9/16] md:aspect-auto md:h-72 w-full overflow-hidden rounded-lg bg-gradient-to-br from-gray-200 to-gray-300">
                  <img 
                    src={invitation.coverImageUrl} 
                    alt="Cover" 
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>

              {/* Info */}
              <div className="flex-1 p-6 space-y-4">
                <div>
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h2 className="text-2xl mb-1">{invitation.title}</h2>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Calendar className="h-4 w-4" />
                        <span>{details.events?.[0]?.location || 'Kadikdawara'} • {new Date(invitation.createdAt).toLocaleDateString('id-ID')}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-3">
                  <div className="text-center bg-slate-100 rounded-lg p-3">
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <Eye className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <div className="text-xl">{invitation.viewCount}</div>
                    <div className="text-xs text-muted-foreground">Pengunjung</div>
                  </div>
                  <div className="text-center bg-slate-100 rounded-lg p-3">
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <MessageSquare className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <div className="text-xl">{invitation.wishCount}</div>
                    <div className="text-xs text-muted-foreground">Ucapan</div>
                  </div>
                  <div className="text-center bg-slate-100 rounded-lg p-3">
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <Users className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <div className="text-xl">{invitation.rsvpCount}</div>
                    <div className="text-xs text-muted-foreground">RSVP</div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex flex-col sm:flex-row gap-2">
                  <Button className="bg-green-600 hover:bg-green-700 flex-1 sm:flex-none">
                    <Share2 className="h-4 w-4 mr-2" />
                    Bagikan
                  </Button>
                  <Button variant="outline" className="flex-1 sm:flex-none" asChild>
                    <a href={fullInvitationLink} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Lihat
                    </a>
                  </Button>
                  <div className="flex gap-2 flex-1">
                    <Input 
                      value={fullInvitationLink} 
                      readOnly 
                      className="text-sm flex-1"
                    />
                    <Button variant="outline" size="icon" onClick={handleCopyLink}>
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 lg:grid-cols-4">
            <TabsTrigger value="konten">Konten</TabsTrigger>
            <TabsTrigger value="pengaturan">Pengaturan</TabsTrigger>
            <TabsTrigger value="media">Media</TabsTrigger>
            <TabsTrigger value="lanjutan">Lanjutan</TabsTrigger>
          </TabsList>

          {/* Tab: Konten */}
          <TabsContent value="konten" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  Kelola Bagian Undangan
                </CardTitle>
                <CardDescription>
                  Aktifkan atau nonaktifkan bagian yang ingin ditampilkan di undangan Anda
                </CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                {sections.map((section, index) => {
                  const Icon = section.icon;
                  return (
                    <div key={section.id}>
                      <div className="flex items-center justify-between p-4 hover:bg-slate-50 transition-colors">
                        <div className="flex items-center gap-3">
                          <GripVertical className="h-4 w-4 text-gray-400 cursor-grab" />
                          <div className={`p-2 rounded-lg ${section.color} bg-opacity-10`}>
                            <Icon className={`h-4 w-4 ${section.color.replace('bg-', 'text-')}`} />
                          </div>
                          <div>
                            <div className="font-medium text-sm">{section.label}</div>
                            <div className="text-xs text-muted-foreground">
                              {section.enabled ? 'Aktif' : 'Tidak aktif'}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Switch 
                            checked={section.enabled} 
                            onCheckedChange={() => handleToggleSection(section.id)}
                          />
                          <Button 
                            variant="outline" 
                            size="sm"
                            disabled={!section.enabled}
                          >
                            Edit
                          </Button>
                        </div>
                      </div>
                      {index < sections.length - 1 && <Separator />}
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            {/* Form Data Mempelai */}
            <Card>
              <CardHeader>
                <CardTitle>Data Mempelai</CardTitle>
                <CardDescription>Informasi lengkap mempelai wanita dan pria</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                  <div className="space-y-4 rounded-lg border p-4 bg-pink-50/50">
                    <h3 className="font-semibold flex items-center gap-2">
                      <Heart className="h-4 w-4 text-pink-500" />
                      Mempelai Wanita
                    </h3>
                    <div className="space-y-2">
                      <Label>Nama Lengkap</Label>
                      <Input 
                        value={details.bride?.name || ''} 
                        onChange={(e) => setDetails(p => ({
                          ...p, 
                          bride: {...p.bride!, name: e.target.value}
                        }))} 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Nama Ayah</Label>
                      <Input 
                        value={details.bride?.father || ''} 
                        onChange={(e) => setDetails(p => ({
                          ...p, 
                          bride: {...p.bride!, father: e.target.value}
                        }))} 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Nama Ibu</Label>
                      <Input 
                        value={details.bride?.mother || ''} 
                        onChange={(e) => setDetails(p => ({
                          ...p, 
                          bride: {...p.bride!, mother: e.target.value}
                        }))} 
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-4 rounded-lg border p-4 bg-blue-50/50">
                    <h3 className="font-semibold flex items-center gap-2">
                      <Users className="h-4 w-4 text-blue-500" />
                      Mempelai Pria
                    </h3>
                    <div className="space-y-2">
                      <Label>Nama Lengkap</Label>
                      <Input 
                        value={details.groom?.name || ''} 
                        onChange={(e) => setDetails(p => ({
                          ...p, 
                          groom: {...p.groom!, name: e.target.value}
                        }))} 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Nama Ayah</Label>
                      <Input 
                        value={details.groom?.father || ''} 
                        onChange={(e) => setDetails(p => ({
                          ...p, 
                          groom: {...p.groom!, father: e.target.value}
                        }))} 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Nama Ibu</Label>
                      <Input 
                        value={details.groom?.mother || ''} 
                        onChange={(e) => setDetails(p => ({
                          ...p, 
                          groom: {...p.groom!, mother: e.target.value}
                        }))} 
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Form Jadwal Acara */}
            <Card>
              <CardHeader>
                <CardTitle>Jadwal Acara</CardTitle>
                <CardDescription>Detail waktu dan lokasi acara pernikahan</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {details.events?.map((event, index) => (
                  <div key={index} className="space-y-4 rounded-lg border p-4 bg-slate-50">
                    <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                      <div className="space-y-2">
                        <Label>Nama Acara</Label>
                        <Input 
                          value={event.name} 
                          onChange={(e) => handleNestedChange('events', index, 'name', e.target.value)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Tanggal & Waktu</Label>
                        <Input 
                          type="datetime-local" 
                          value={event.date} 
                          onChange={(e) => handleNestedChange('events', index, 'date', e.target.value)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Lokasi</Label>
                        <Input 
                          value={event.location} 
                          onChange={(e) => handleNestedChange('events', index, 'location', e.target.value)} 
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab: Pengaturan */}
          <TabsContent value="pengaturan" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Pengaturan Umum</CardTitle>
                <CardDescription>Konfigurasi dasar undangan Anda</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <Label>Status Publikasi</Label>
                    <p className="text-sm text-muted-foreground">
                      {isPublished ? 'Undangan dapat diakses publik' : 'Undangan dalam mode draft'}
                    </p>
                  </div>
                  <Switch checked={isPublished} onCheckedChange={setIsPublished} />
                </div>
                <div className="space-y-2">
                  <Label>Quote / Doa</Label>
                  <Textarea 
                    value={details.quote || ''} 
                    onChange={(e) => handleDetailChange('quote', e.target.value)}
                    placeholder="Masukkan quote atau doa pembuka..."
                    rows={4}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab: Media */}
          <TabsContent value="media" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Galeri Foto</CardTitle>
                    <CardDescription>Upload foto untuk galeri undangan</CardDescription>
                  </div>
                  <Button variant="outline">
                    <Upload className="h-4 w-4 mr-2" />
                    Upload
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
                  {[1, 2, 3, 4].map((i) => (
                    <div key={i} className="relative aspect-square group bg-slate-100 rounded-lg flex items-center justify-center border-2 border-dashed">
                      <ImageIcon className="h-8 w-8 text-muted-foreground" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Musik & Video</CardTitle>
                <CardDescription>Tambahkan musik latar dan video</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>URL Musik (MP3)</Label>
                  <Input 
                    value={details.musicUrl || ''} 
                    onChange={(e) => handleDetailChange('musicUrl', e.target.value)}
                    placeholder="https://..."
                  />
                </div>
                <div className="space-y-2">
                  <Label>URL Video YouTube</Label>
                  <Input 
                    value={details.videoUrl || ''} 
                    onChange={(e) => handleDetailChange('videoUrl', e.target.value)}
                    placeholder="https://youtu.be/..."
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab: Lanjutan */}
          <TabsContent value="lanjutan" className="space-y-6">
            <Card className="border-yellow-200 bg-yellow-50">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="bg-yellow-500 p-3 rounded-full">
                    <Sparkles className="h-6 w-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold mb-2">Upgrade ke Premium</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Dapatkan akses ke fitur premium seperti tema custom, unlimited foto, dan analytics lengkap
                    </p>
                    <Button className="bg-yellow-600 hover:bg-yellow-700">
                      Upgrade Sekarang
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Floating Save Button */}
        <div className="sticky bottom-4 mt-8 flex justify-end">
          <Button size="lg" onClick={handleSaveChanges} className="shadow-lg">
            Simpan Semua Perubahan
          </Button>
        </div>
      </main>
    </div>
  );
}
