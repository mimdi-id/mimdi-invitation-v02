
  # Edit Invitation Page Design

  This is a code bundle for Edit Invitation Page Design. The original project is available at https://www.figma.com/design/dEQFKEiXk18C8ACjNDJCV2/Edit-Invitation-Page-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  