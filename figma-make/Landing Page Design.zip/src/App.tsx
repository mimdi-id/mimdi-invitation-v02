import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Features } from './components/Features';
import { Themes } from './components/Themes';
import { Pricing } from './components/Pricing';
import { Testimonials } from './components/Testimonials';
import { ContactInfo } from './components/ContactInfo';
import { FAQ } from './components/FAQ';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <Hero />
      <Features />
      <Themes />
      <Pricing />
      <Testimonials />
      <ContactInfo />
      <FAQ />
      <Footer />
    </div>
  );
}
