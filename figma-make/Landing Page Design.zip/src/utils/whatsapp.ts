export const openWhatsApp = (message: string = '') => {
  const phoneNumber = '6281234567890'; // Ganti dengan nomor WhatsApp Anda (format: 62xxx tanpa +)
  const defaultMessage = message || 'Halo InvitasiKu, saya tertarik untuk membuat undangan digital. Mohon info lebih lanjut.';
  const encodedMessage = encodeURIComponent(defaultMessage);
  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;
  
  window.open(whatsappUrl, '_blank');
};

export const openWhatsAppOrder = (packageName?: string) => {
  const message = packageName 
    ? `Halo InvitasiKu, saya tertarik untuk memesan paket ${packageName}. Mohon info lebih lanjut mengenai proses pemesanan.`
    : 'Halo InvitasiKu, saya tertarik untuk membuat undangan digital. Mohon info lebih lanjut.';
  
  openWhatsApp(message);
};

export const openWhatsAppConsultation = () => {
  const message = 'Halo InvitasiKu, saya ingin konsultasi gratis mengenai undangan digital untuk acara saya. Kapan bisa diatur?';
  openWhatsApp(message);
};
