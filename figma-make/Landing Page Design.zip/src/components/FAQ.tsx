import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from './ui/accordion';
import { Card } from './ui/card';
import { MessageCircle } from 'lucide-react';
import { Button } from './ui/button';
import { motion } from 'motion/react';
import { openWhatsApp } from '../utils/whatsapp';

export function FAQ() {
  const faqs = [
    {
      question: 'Berapa lama proses pembuatan undangan digital?',
      answer: 'Proses pembuatan undangan digital kami sangat cepat, hanya membutuhkan waktu 1x24 jam setelah semua data dan pembayaran diterima. Untuk revisi, kami akan langsung proses maksimal 6 jam.'
    },
    {
      question: 'Apakah bisa revisi undangan setelah jadi?',
      answer: 'Tentu bisa! Untuk paket Basic, Anda mendapatkan 2x revisi gratis. Paket Premium dan Luxury mendapatkan revisi unlimited sampai Anda puas dengan hasilnya. Revisi meliputi perubahan teks, foto, dan penyesuaian kecil lainnya.'
    },
    {
      question: 'Bagaimana cara pembayaran dan apa saja metode yang tersedia?',
      answer: 'Pembayaran dilakukan 100% di muka sebelum proses pembuatan. Kami menerima transfer Bank (BCA, Mandiri, BRI, BNI), E-Wallet (GoPay, OVO, DANA, ShopeePay), dan QRIS. Setelah transfer, mohon kirimkan bukti pembayaran ke WhatsApp kami.'
    },
    {
      question: 'Apakah undangan bisa diakses tanpa internet?',
      answer: 'Undangan digital kami berbasis web, sehingga memerlukan koneksi internet untuk diakses. Namun, kami sudah optimasi loading speed agar tetap cepat meski dengan internet yang lambat. File size juga kami minimalkan agar hemat kuota.'
    },
    {
      question: 'Berapa jumlah maksimal tamu yang bisa diundang?',
      answer: 'Untuk paket Basic, maksimal 100 tamu. Paket Premium dan Luxury unlimited tamu. Setiap tamu akan mendapatkan link personal yang dapat di-tracking kehadirannya melalui fitur RSVP.'
    },
    {
      question: 'Apakah ada biaya perpanjangan atau maintenance bulanan?',
      answer: 'Tidak ada biaya tambahan! Harga sudah termasuk hosting dan maintenance selama periode aktif. Paket Basic aktif 30 hari, Premium 60 hari, dan Luxury selamanya. Jika ingin perpanjang, ada biaya tambahan mulai dari Rp 50.000/bulan.'
    },
    {
      question: 'Bagaimana cara membagikan undangan digital ke tamu?',
      answer: 'Sangat mudah! Setelah undangan selesai, Anda akan mendapatkan link yang bisa langsung dibagikan via WhatsApp, Instagram, Facebook, atau platform lainnya. Kami juga sediakan template pesan yang bisa langsung di-copy paste.'
    },
    {
      question: 'Apakah bisa menambahkan video atau musik sendiri?',
      answer: 'Bisa! Anda bisa menambahkan video pre-wedding, video cinematic, atau musik favorit Anda. Untuk video, maksimal durasi 2 menit dan ukuran 50MB. Musik bisa dari YouTube atau file MP3 yang Anda upload.'
    },
    {
      question: 'Apakah desain/tema bisa di-custom sesuai keinginan?',
      answer: 'Untuk paket Basic dan Premium, Anda bisa pilih dari 50+ tema yang sudah tersedia dengan penyesuaian warna dan font. Paket Luxury bisa full custom desain sesuai request Anda, bahkan bisa dari desain sendiri!'
    },
    {
      question: 'Bagaimana dengan data tamu dan ucapan yang masuk?',
      answer: 'Semua data RSVP dan ucapan akan tersimpan otomatis di dashboard yang bisa Anda akses kapan saja. Anda juga bisa download data dalam format Excel untuk keperluan dokumentasi atau follow up ke tamu.'
    },
    {
      question: 'Apakah undangan bisa untuk selain pernikahan?',
      answer: 'Tentu! Kami juga melayani undangan digital untuk berbagai acara seperti lamaran, engagement, aqiqah, ulang tahun, khitanan, syukuran, dan acara lainnya. Tema dan fiturnya bisa disesuaikan dengan jenis acara.'
    },
    {
      question: 'Bagaimana jika ada masalah teknis saat undangan sudah live?',
      answer: 'Tenang! Kami punya tim support 24/7 yang siap membantu. Jika ada masalah teknis, langsung hubungi kami via WhatsApp dan kami akan segera perbaiki. Kami juga selalu backup data untuk antisipasi.'
    }
  ];

  return (
    <section id="faq" className="py-20 bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
        >
          <span className="text-[#ff5722] mb-4 block">FAQ</span>
          <h2 className="mb-4">Pertanyaan yang Sering Diajukan</h2>
          <p className="text-xl text-gray-600">
            Temukan jawaban untuk pertanyaan umum seputar layanan kami
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.6 }}
        >
          <Card className="border-0 shadow-xl p-4 md:p-8 mb-8">
            <Accordion type="single" collapsible className="w-full">
              {faqs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`}>
                  <AccordionTrigger className="text-left hover:text-[#ff5722]">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-gray-600 leading-relaxed">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </Card>
        </motion.div>

        {/* Still Have Questions CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <Card className="border-0 shadow-xl bg-gradient-to-br from-[#ff5722] to-[#ff1744] text-white">
            <div className="p-8 text-center">
              <MessageCircle className="mx-auto mb-4 text-white" size={48} />
              <h3 className="text-white mb-4">
                Masih Ada Pertanyaan?
              </h3>
              <p className="text-white/90 mb-6 max-w-2xl mx-auto">
                Tim kami siap membantu Anda! Jangan ragu untuk menghubungi kami via WhatsApp 
                untuk konsultasi gratis dan informasi lebih lanjut.
              </p>
              <Button 
                onClick={() => openWhatsApp()}
                className="bg-white text-[#ff5722] hover:bg-gray-100 px-8 py-6 text-lg"
              >
                <MessageCircle className="mr-2" size={20} />
                Hubungi via WhatsApp
              </Button>
            </div>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}
