import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Eye, Heart } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { motion } from 'motion/react';

export function Themes() {
  const themes = [
    {
      id: 1,
      name: 'Elegant Floral',
      category: 'Modern',
      image: 'https://images.unsplash.com/photo-1553002652-763b1e623d9a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyb21hbnRpYyUyMHdlZGRpbmclMjBmbG93ZXJzfGVufDF8fHx8MTc2MDc4OTM4MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      popular: true
    },
    {
      id: 2,
      name: 'Minimalist White',
      category: 'Minimalist',
      image: 'https://images.unsplash.com/photo-1592677818226-af94f44b04a5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsaXN0JTIwd2VkZGluZyUyMGRlY29yYXRpb258ZW58MXx8fHwxNzYwNzkyNDQzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      popular: false
    },
    {
      id: 3,
      name: 'Classic Invitation',
      category: 'Classic',
      image: 'https://images.unsplash.com/photo-1738025275088-554086913a78?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwaW52aXRhdGlvbiUyMGNhcmR8ZW58MXx8fHwxNzYwNzkyNDQzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      popular: true
    },
    {
      id: 4,
      name: 'Modern Ceremony',
      category: 'Modern',
      image: 'https://images.unsplash.com/photo-1758497335981-faffb9e603fd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjB3ZWRkaW5nJTIwY2VyZW1vbnl8ZW58MXx8fHwxNzYwNzkyNDQ0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      popular: false
    },
    {
      id: 5,
      name: 'Romantic Gold',
      category: 'Luxury',
      image: 'https://images.unsplash.com/photo-1739216906046-afc47ed589fb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwcmluZ3MlMjBlbGVnYW50fGVufDF8fHx8MTc2MDc1NjMyN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      popular: true
    },
    {
      id: 6,
      name: 'Garden Romance',
      category: 'Nature',
      image: 'https://images.unsplash.com/photo-1724812773350-a7d0bf664417?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwd2VkZGluZyUyMGNvdXBsZXxlbnwxfHx8fDE3NjA3OTI0NDJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      popular: false
    }
  ];

  return (
    <section id="themes" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
        >
          <span className="text-[#ff5722] mb-4 block">Katalog Tema</span>
          <h2 className="mb-4">Pilih Tema Favorit Anda</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Lebih dari 50+ tema premium yang dapat disesuaikan dengan gaya dan tema pernikahan Anda
          </p>
        </motion.div>

        {/* Category Filter */}
        <motion.div 
          className="flex flex-wrap justify-center gap-4 mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <Badge className="px-4 py-2 bg-[#ff5722] hover:bg-[#ff1744] cursor-pointer">
            Semua Tema
          </Badge>
          <Badge variant="outline" className="px-4 py-2 cursor-pointer hover:bg-gray-100">
            Modern
          </Badge>
          <Badge variant="outline" className="px-4 py-2 cursor-pointer hover:bg-gray-100">
            Minimalist
          </Badge>
          <Badge variant="outline" className="px-4 py-2 cursor-pointer hover:bg-gray-100">
            Classic
          </Badge>
          <Badge variant="outline" className="px-4 py-2 cursor-pointer hover:bg-gray-100">
            Luxury
          </Badge>
        </motion.div>

        {/* Themes Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {themes.map((theme, index) => (
            <motion.div
              key={theme.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ 
                duration: 0.5, 
                delay: index * 0.1,
                ease: [0.25, 0.1, 0.25, 1]
              }}
            >
              <Card 
                className="group overflow-hidden border-0 shadow-lg hover:shadow-2xl transition-all duration-300"
              >
              <div className="relative aspect-[3/4] overflow-hidden">
                <ImageWithFallback
                  src={theme.image}
                  alt={theme.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                {theme.popular && (
                  <Badge className="absolute top-4 right-4 bg-[#ff1744] hover:bg-[#ff1744]">
                    <Heart size={12} className="mr-1" />
                    Popular
                  </Badge>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <Button className="bg-white text-[#ff5722] hover:bg-gray-100">
                    <Eye className="mr-2" size={16} />
                    Preview Demo
                  </Button>
                </div>
              </div>
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <h3>{theme.name}</h3>
                  <Badge variant="outline" className="text-[#ff5722] border-[#ff5722]">
                    {theme.category}
                  </Badge>
                </div>
                <p className="text-gray-600 mb-4">
                  Tema {theme.category.toLowerCase()} yang elegan dan modern
                </p>
                <Button 
                  variant="outline" 
                  className="w-full border-[#ff5722] text-[#ff5722] hover:bg-[#ff5722] hover:text-white"
                >
                  Pilih Tema Ini
                </Button>
              </CardContent>
            </Card>
            </motion.div>
          ))}
        </div>

        <motion.div 
          className="text-center mt-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.6 }}
        >
          <Button className="bg-[#ff5722] hover:bg-[#ff1744] text-white px-8 py-6">
            Lihat Semua Tema
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
