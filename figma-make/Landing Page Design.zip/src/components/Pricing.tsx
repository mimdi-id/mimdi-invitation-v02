import { Card, CardContent, CardHeader } from './ui/card';
import { Button } from './ui/button';
import { Check, Star } from 'lucide-react';
import { Badge } from './ui/badge';
import { motion } from 'motion/react';
import { openWhatsAppOrder, openWhatsAppConsultation } from '../utils/whatsapp';

export function Pricing() {
  const packages = [
    {
      name: 'Basic',
      price: '150.000',
      description: 'Cocok untuk acara intimate',
      popular: false,
      features: [
        'Pilih 1 tema dari 20+ tema basic',
        'Maksimal 100 tamu',
        'Galeri foto (max 10 foto)',
        'Google Maps lokasi acara',
        'Countdown timer',
        'Background musik',
        'Form RSVP',
        'Ucapan & doa tamu',
        'Domain custom (nama.invitasiku.com)',
        'Revisi 2x',
        'Aktif 30 hari'
      ]
    },
    {
      name: 'Premium',
      price: '250.000',
      description: 'Paling populer untuk pernikahan',
      popular: true,
      features: [
        'Pilih dari 50+ tema premium',
        'Unlimited tamu',
        'Galeri foto unlimited',
        'Google Maps & Waze integration',
        'Countdown timer',
        'Background musik custom',
        'Form RSVP advanced',
        'Ucapan & doa tamu',
        'Amplop digital (e-wallet)',
        'Domain custom bebas',
        'Protokol kesehatan COVID-19',
        'Video pre-wedding',
        'Instagram filter',
        'Revisi unlimited',
        'Aktif 60 hari'
      ]
    },
    {
      name: 'Luxury',
      price: '500.000',
      description: 'Untuk pengalaman terbaik',
      popular: false,
      features: [
        'Semua fitur Premium',
        'Custom tema eksklusif',
        'Unlimited tamu & foto',
        'Multiple event (akad & resepsi)',
        'Live streaming integration',
        'QR Code check-in',
        'Guest book digital',
        'Photo booth digital',
        'Story timeline interaktif',
        'Animasi 3D custom',
        'Priority support 24/7',
        'Gratis update fitur baru',
        'Revisi unlimited',
        'Aktif selamanya'
      ]
    }
  ];

  return (
    <section id="pricing" className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
        >
          <span className="text-[#ff5722] mb-4 block">Harga Paket</span>
          <h2 className="mb-4">Pilih Paket yang Tepat</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Harga terjangkau dengan fitur lengkap. Semua paket sudah termasuk hosting dan maintenance
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {packages.map((pkg, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ 
                duration: 0.5, 
                delay: index * 0.2,
                ease: [0.25, 0.1, 0.25, 1]
              }}
            >
              <Card 
                className={`relative overflow-hidden h-full ${
                  pkg.popular 
                    ? 'border-[#ff5722] border-2 shadow-2xl scale-105' 
                    : 'border-gray-200 shadow-lg'
                }`}
              >
              {pkg.popular && (
                <div className="absolute top-0 right-0">
                  <Badge className="bg-[#ff1744] hover:bg-[#ff1744] rounded-tl-none rounded-br-none px-4 py-2">
                    <Star size={14} className="mr-1" />
                    Terpopuler
                  </Badge>
                </div>
              )}
              
              <CardHeader className="text-center pb-8 pt-10">
                <h3 className="mb-2">{pkg.name}</h3>
                <p className="text-gray-600 mb-6">{pkg.description}</p>
                <div className="mb-4">
                  <span className="text-4xl" style={{ color: pkg.popular ? '#ff5722' : '#333' }}>
                    Rp {pkg.price}
                  </span>
                  <span className="text-gray-500">/paket</span>
                </div>
              </CardHeader>

              <CardContent className="px-6 pb-8">
                <ul className="space-y-4 mb-8">
                  {pkg.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <Check 
                        size={20} 
                        className="flex-shrink-0 mt-0.5" 
                        style={{ color: pkg.popular ? '#ff5722' : '#22c55e' }}
                      />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Button 
                  onClick={() => openWhatsAppOrder(pkg.name)}
                  className={`w-full py-6 ${
                    pkg.popular 
                      ? 'bg-[#ff5722] hover:bg-[#ff1744] text-white' 
                      : 'bg-white border-2 border-[#ff5722] text-[#ff5722] hover:bg-[#ff5722] hover:text-white'
                  }`}
                >
                  Pilih Paket {pkg.name}
                </Button>
              </CardContent>
            </Card>
            </motion.div>
          ))}
        </div>

        {/* Additional Info */}
        <div className="mt-16 text-center">
          <Card className="max-w-4xl mx-auto bg-gradient-to-r from-[#ff8a65]/10 to-[#ff5722]/10 border-[#ff5722]/20">
            <CardContent className="p-8">
              <h3 className="mb-4">Butuh Paket Custom?</h3>
              <p className="text-gray-600 mb-6">
                Kami juga menyediakan paket custom sesuai kebutuhan Anda. 
                Hubungi kami untuk konsultasi gratis dan penawaran khusus.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  onClick={() => openWhatsAppOrder('Custom')}
                  className="bg-[#ff5722] hover:bg-[#ff1744] text-white px-8"
                >
                  Hubungi via WhatsApp
                </Button>
                <Button 
                  onClick={openWhatsAppConsultation}
                  variant="outline" 
                  className="border-[#ff5722] text-[#ff5722] hover:bg-[#ff5722] hover:text-white px-8"
                >
                  Konsultasi Gratis
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
