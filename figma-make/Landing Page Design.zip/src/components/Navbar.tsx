import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { Button } from './ui/button';
import { openWhatsApp } from '../utils/whatsapp';

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsOpen(false);
    }
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex-shrink-0">
            <span className="text-2xl" style={{ color: '#ff5722' }}>
              InvitasiKu
            </span>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-8">
            <button
              onClick={() => scrollToSection('hero')}
              className="text-gray-700 hover:text-[#ff5722] transition-colors"
            >
              Beranda
            </button>
            <button
              onClick={() => scrollToSection('features')}
              className="text-gray-700 hover:text-[#ff5722] transition-colors"
            >
              Fitur
            </button>
            <button
              onClick={() => scrollToSection('themes')}
              className="text-gray-700 hover:text-[#ff5722] transition-colors"
            >
              Katalog Tema
            </button>
            <button
              onClick={() => scrollToSection('pricing')}
              className="text-gray-700 hover:text-[#ff5722] transition-colors"
            >
              Harga
            </button>
            <button
              onClick={() => scrollToSection('testimonials')}
              className="text-gray-700 hover:text-[#ff5722] transition-colors"
            >
              Testimoni
            </button>
            <button
              onClick={() => scrollToSection('faq')}
              className="text-gray-700 hover:text-[#ff5722] transition-colors"
            >
              FAQ
            </button>
            <Button
              onClick={() => openWhatsApp()}
              className="bg-[#ff5722] hover:bg-[#ff1744] text-white"
            >
              Buat Undangan
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-gray-700 hover:text-[#ff5722]"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-white border-t border-gray-100">
          <div className="px-4 pt-2 pb-4 space-y-3">
            <button
              onClick={() => scrollToSection('hero')}
              className="block w-full text-left py-2 text-gray-700 hover:text-[#ff5722] transition-colors"
            >
              Beranda
            </button>
            <button
              onClick={() => scrollToSection('features')}
              className="block w-full text-left py-2 text-gray-700 hover:text-[#ff5722] transition-colors"
            >
              Fitur
            </button>
            <button
              onClick={() => scrollToSection('themes')}
              className="block w-full text-left py-2 text-gray-700 hover:text-[#ff5722] transition-colors"
            >
              Katalog Tema
            </button>
            <button
              onClick={() => scrollToSection('pricing')}
              className="block w-full text-left py-2 text-gray-700 hover:text-[#ff5722] transition-colors"
            >
              Harga
            </button>
            <button
              onClick={() => scrollToSection('testimonials')}
              className="block w-full text-left py-2 text-gray-700 hover:text-[#ff5722] transition-colors"
            >
              Testimoni
            </button>
            <button
              onClick={() => scrollToSection('faq')}
              className="block w-full text-left py-2 text-gray-700 hover:text-[#ff5722] transition-colors"
            >
              FAQ
            </button>
            <Button
              onClick={() => openWhatsApp()}
              className="w-full bg-[#ff5722] hover:bg-[#ff1744] text-white"
            >
              Buat Undangan
            </Button>
          </div>
        </div>
      )}
    </nav>
  );
}
