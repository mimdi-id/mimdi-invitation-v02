import { Button } from './ui/button';
import { Heart, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';

export function Hero() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="hero" className="relative min-h-screen flex items-center pt-16 bg-gradient-to-br from-[#ff8a65] via-[#ff5722] to-[#ff1744]">
      {/* Decorative Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div 
          className="absolute top-20 right-20 w-72 h-72 bg-white/10 rounded-full blur-3xl"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        ></motion.div>
        <motion.div 
          className="absolute bottom-20 left-20 w-96 h-96 bg-[#ff5252]/20 rounded-full blur-3xl"
          animate={{
            scale: [1, 1.1, 1],
            opacity: [0.2, 0.4, 0.2],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        ></motion.div>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="max-w-3xl">
          <motion.div 
            className="flex items-center gap-2 mb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Sparkles className="text-white" size={24} />
            <span className="text-white/90">Undangan Digital Modern</span>
          </motion.div>
          
          <motion.h1 
            className="text-white mb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            Buat Undangan Pernikahan Digital yang Berkesan
          </motion.h1>
          
          <motion.p 
            className="text-xl text-white/90 mb-8 leading-relaxed"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            Ciptakan momen istimewa dengan undangan digital yang elegan dan interaktif. 
            Lebih dari 50+ tema premium siap untuk pernikahan Anda.
          </motion.p>

          <motion.div 
            className="flex flex-col sm:flex-row gap-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
          >
            <Button
              onClick={() => scrollToSection('themes')}
              className="bg-white text-[#ff5722] hover:bg-gray-100 px-8 py-6 text-lg"
            >
              <Heart className="mr-2" size={20} />
              Lihat Katalog Tema
            </Button>
            <Button
              onClick={() => scrollToSection('pricing')}
              variant="outline"
              className="border-2 border-white text-white hover:bg-white hover:text-[#ff5722] px-8 py-6 text-lg"
            >
              Cek Harga
            </Button>
          </motion.div>

          {/* Stats */}
          <motion.div 
            className="grid grid-cols-3 gap-8 mt-12 pt-12 border-t border-white/20"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.8 }}
          >
            <div>
              <div className="text-3xl text-white mb-2">5000+</div>
              <div className="text-white/80">Pasangan Bahagia</div>
            </div>
            <div>
              <div className="text-3xl text-white mb-2">50+</div>
              <div className="text-white/80">Tema Premium</div>
            </div>
            <div>
              <div className="text-3xl text-white mb-2">4.9/5</div>
              <div className="text-white/80">Rating Pelanggan</div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
