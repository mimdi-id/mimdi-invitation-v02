import { 
  Smartphone, 
  Heart, 
  Music, 
  MapPin, 
  Calendar, 
  Gift, 
  Image, 
  Share2,
  Clock,
  MessageSquare,
  Link2,
  Sparkles
} from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { motion } from 'motion/react';

export function Features() {
  const features = [
    {
      icon: <Smartphone className="text-[#ff5722]" size={32} />,
      title: 'Responsive Design',
      description: 'Tampil sempurna di semua perangkat, dari smartphone hingga desktop'
    },
    {
      icon: <Heart className="text-[#ff5722]" size={32} />,
      title: 'Desain Elegan',
      description: 'Tema-tema modern dan elegan yang dapat disesuaikan dengan gaya Anda'
    },
    {
      icon: <Music className="text-[#ff5722]" size={32} />,
      title: 'Background Music',
      description: 'Tambahkan lagu favorit sebagai musik latar undangan Anda'
    },
    {
      icon: <MapPin className="text-[#ff5722]" size={32} />,
      title: 'Google Maps',
      description: 'Integrasi peta untuk memudahkan tamu menemukan lokasi acara'
    },
    {
      icon: <Calendar className="text-[#ff5722]" size={32} />,
      title: 'Save The Date',
      description: 'Fitur reminder dan countdown untuk hari spesial Anda'
    },
    {
      icon: <Gift className="text-[#ff5722]" size={32} />,
      title: 'Gift Registry',
      description: 'Opsi amplop digital untuk memudahkan tamu memberikan hadiah'
    },
    {
      icon: <Image className="text-[#ff5722]" size={32} />,
      title: 'Galeri Foto',
      description: 'Tampilkan momen-momen indah dalam galeri foto yang cantik'
    },
    {
      icon: <MessageSquare className="text-[#ff5722]" size={32} />,
      title: 'Ucapan & RSVP',
      description: 'Terima ucapan dan konfirmasi kehadiran tamu secara real-time'
    },
    {
      icon: <Share2 className="text-[#ff5722]" size={32} />,
      title: 'Mudah Dibagikan',
      description: 'Bagikan undangan via WhatsApp, Instagram, dan media sosial lainnya'
    },
    {
      icon: <Clock className="text-[#ff5722]" size={32} />,
      title: 'Proses Cepat',
      description: 'Undangan siap dalam 1x24 jam setelah data lengkap diterima'
    },
    {
      icon: <Link2 className="text-[#ff5722]" size={32} />,
      title: 'Custom Domain',
      description: 'Dapatkan link undangan yang personal dan mudah diingat'
    },
    {
      icon: <Sparkles className="text-[#ff5722]" size={32} />,
      title: 'Animasi Smooth',
      description: 'Animasi yang halus dan menarik untuk pengalaman yang berkesan'
    }
  ];

  return (
    <section id="features" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
        >
          <span className="text-[#ff5722] mb-4 block">Fitur Lengkap</span>
          <h2 className="mb-4">Semua yang Anda Butuhkan</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Dilengkapi dengan berbagai fitur modern untuk membuat undangan digital yang sempurna
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ 
                duration: 0.5, 
                delay: index * 0.1,
                ease: [0.25, 0.1, 0.25, 1]
              }}
            >
              <Card 
                className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300 bg-white h-full"
              >
                <CardContent className="p-6">
                  <div className="mb-4">{feature.icon}</div>
                  <h3 className="mb-3">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
