import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Phone, MessageCircle, Mail, Heart } from 'lucide-react';
import { motion } from 'motion/react';
import { openWhatsApp } from '../utils/whatsapp';

export function ContactInfo() {
  return (
    <section id="contact" className="py-20 bg-gradient-to-br from-[#ff8a65]/5 to-[#ff5722]/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
        >
          <span className="text-[#ff5722] mb-4 block">Hubungi Kami</span>
          <h2 className="mb-4">Siap Membuat Undangan Impian Anda?</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Tim kami siap membantu mewujudkan undangan digital yang sempurna untuk hari spesial Anda
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Why Choose Us */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.6 }}
          >
            <Card className="border-0 shadow-xl bg-gradient-to-br from-[#ff5722] to-[#ff1744] text-white h-full">
              <CardContent className="p-8">
                <h3 className="text-white mb-6">Kenapa Pilih InvitasiKu?</h3>
                <ul className="space-y-4">
                  <li className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0 mt-1">
                      ✓
                    </div>
                    <div>
                      <div className="mb-1">Proses Cepat 1x24 Jam</div>
                      <div className="text-sm text-white/80">Undangan siap setelah data lengkap diterima</div>
                    </div>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0 mt-1">
                      ✓
                    </div>
                    <div>
                      <div className="mb-1">Harga Terjangkau</div>
                      <div className="text-sm text-white/80">Mulai dari Rp 150.000 dengan fitur lengkap</div>
                    </div>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0 mt-1">
                      ✓
                    </div>
                    <div>
                      <div className="mb-1">Revisi Gratis</div>
                      <div className="text-sm text-white/80">Revisi sampai Anda puas dengan hasilnya</div>
                    </div>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0 mt-1">
                      ✓
                    </div>
                    <div>
                      <div className="mb-1">Customer Support 24/7</div>
                      <div className="text-sm text-white/80">Admin siap membantu kapan saja</div>
                    </div>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0 mt-1">
                      ✓
                    </div>
                    <div>
                      <div className="mb-1">50+ Tema Premium</div>
                      <div className="text-sm text-white/80">Pilihan tema modern dan elegan</div>
                    </div>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0 mt-1">
                      ✓
                    </div>
                    <div>
                      <div className="mb-1">Garansi Kepuasan</div>
                      <div className="text-sm text-white/80">100% uang kembali jika tidak puas</div>
                    </div>
                  </li>
                </ul>

                <div className="mt-8 pt-8 border-t border-white/20">
                  <Button 
                    onClick={() => openWhatsApp()}
                    className="w-full bg-white text-[#ff5722] hover:bg-gray-100 py-6 text-lg"
                  >
                    <Heart className="mr-2" size={20} />
                    Mulai Buat Undangan
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Contact Details */}
          <motion.div
            className="space-y-8"
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.6 }}
          >
            <Card className="border-0 shadow-xl">
              <CardContent className="p-8">
                <h3 className="mb-6">Hubungi Kami Langsung</h3>
                <div className="space-y-4">
                  <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer">
                    <div className="w-12 h-12 bg-[#25D366] rounded-full flex items-center justify-center">
                      <Phone className="text-white" size={24} />
                    </div>
                    <div>
                      <div className="text-sm text-gray-600">WhatsApp</div>
                      <div className="text-gray-900">+62 812-3456-7890</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer">
                    <div className="w-12 h-12 bg-[#E4405F] rounded-full flex items-center justify-center">
                      <MessageCircle className="text-white" size={24} />
                    </div>
                    <div>
                      <div className="text-sm text-gray-600">Instagram</div>
                      <div className="text-gray-900">@invitasiku</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer">
                    <div className="w-12 h-12 bg-[#ff5722] rounded-full flex items-center justify-center">
                      <Mail className="text-white" size={24} />
                    </div>
                    <div>
                      <div className="text-sm text-gray-600">Email</div>
                      <div className="text-gray-900">info@invitasiku.com</div>
                    </div>
                  </div>
                </div>

                <div className="mt-6 pt-6 border-t border-gray-200">
                  <p className="text-sm text-gray-600">
                    Jam Operasional: <br />
                    <span className="text-gray-900">Senin - Sabtu: 09:00 - 21:00 WIB</span><br />
                    <span className="text-gray-900">Minggu & Tanggal Merah: 10:00 - 18:00 WIB</span>
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-xl bg-gradient-to-br from-gray-50 to-white">
              <CardContent className="p-8">
                <h3 className="mb-4">Promo Spesial!</h3>
                <div className="mb-4">
                  <div className="inline-block px-4 py-2 bg-[#ff5722] text-white rounded-full mb-4">
                    Diskon 20% untuk 10 pesanan pertama hari ini!
                  </div>
                </div>
                <p className="text-gray-600 mb-6">
                  Dapatkan harga spesial dengan memesan hari ini. Promo terbatas dan berlaku untuk semua paket!
                </p>
                <Button 
                  onClick={() => openWhatsApp('Halo InvitasiKu, saya tertarik dengan promo spesial hari ini. Mohon info lebih lanjut.')}
                  variant="outline" 
                  className="w-full border-2 border-[#ff5722] text-[#ff5722] hover:bg-[#ff5722] hover:text-white py-6"
                >
                  Klaim Promo Sekarang
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Quick Stats */}
        <motion.div 
          className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <div className="text-center">
            <div className="text-3xl mb-2" style={{ color: '#ff5722' }}>5000+</div>
            <div className="text-gray-600">Undangan Dibuat</div>
          </div>
          <div className="text-center">
            <div className="text-3xl mb-2" style={{ color: '#ff5722' }}>4.9/5</div>
            <div className="text-gray-600">Rating Pelanggan</div>
          </div>
          <div className="text-center">
            <div className="text-3xl mb-2" style={{ color: '#ff5722' }}>1000+</div>
            <div className="text-gray-600">Review Positif</div>
          </div>
          <div className="text-center">
            <div className="text-3xl mb-2" style={{ color: '#ff5722' }}>24/7</div>
            <div className="text-gray-600">Customer Support</div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
