import { Heart, Instagram, Facebook, Mail, Phone, MapPin } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';

export function Footer() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-gray-900 text-gray-300">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div>
            <h3 className="text-white mb-4">
              InvitasiKu
            </h3>
            <p className="text-gray-400 mb-6">
              Platform undangan digital terpercaya untuk momen spesial Anda. 
              Buat undangan yang berkesan dengan mudah.
            </p>
            <div className="flex gap-4">
              <a href="#" className="text-gray-400 hover:text-[#ff5722] transition-colors">
                <Instagram size={24} />
              </a>
              <a href="#" className="text-gray-400 hover:text-[#ff5722] transition-colors">
                <Facebook size={24} />
              </a>
              <a href="#" className="text-gray-400 hover:text-[#ff5722] transition-colors">
                <Mail size={24} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white mb-4">Menu</h4>
            <ul className="space-y-3">
              <li>
                <button 
                  onClick={() => scrollToSection('hero')}
                  className="text-gray-400 hover:text-[#ff5722] transition-colors"
                >
                  Beranda
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('features')}
                  className="text-gray-400 hover:text-[#ff5722] transition-colors"
                >
                  Fitur
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('themes')}
                  className="text-gray-400 hover:text-[#ff5722] transition-colors"
                >
                  Katalog Tema
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('pricing')}
                  className="text-gray-400 hover:text-[#ff5722] transition-colors"
                >
                  Harga
                </button>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-[#ff5722] transition-colors">
                  Testimonial
                </a>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="text-white mb-4">Bantuan</h4>
            <ul className="space-y-3">
              <li>
                <a href="#" className="text-gray-400 hover:text-[#ff5722] transition-colors">
                  FAQ
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-[#ff5722] transition-colors">
                  Cara Pemesanan
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-[#ff5722] transition-colors">
                  Syarat & Ketentuan
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-[#ff5722] transition-colors">
                  Kebijakan Privasi
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-[#ff5722] transition-colors">
                  Hubungi Kami
                </a>
              </li>
            </ul>
          </div>

          {/* Contact & Newsletter */}
          <div>
            <h4 className="text-white mb-4">Kontak</h4>
            <ul className="space-y-4 mb-6">
              <li className="flex items-start gap-3">
                <Phone size={20} className="text-[#ff5722] flex-shrink-0 mt-1" />
                <div>
                  <div className="text-gray-400">+62 812-3456-7890</div>
                  <div className="text-sm text-gray-500">Senin - Sabtu, 09:00 - 21:00</div>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <Mail size={20} className="text-[#ff5722] flex-shrink-0 mt-1" />
                <div className="text-gray-400">info@invitasiku.com</div>
              </li>
              <li className="flex items-start gap-3">
                <MapPin size={20} className="text-[#ff5722] flex-shrink-0 mt-1" />
                <div className="text-gray-400">Jakarta, Indonesia</div>
              </li>
            </ul>

            <div>
              <p className="text-sm text-gray-400 mb-3">Subscribe newsletter kami</p>
              <div className="flex gap-2">
                <Input 
                  type="email" 
                  placeholder="Email Anda" 
                  className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                />
                <Button className="bg-[#ff5722] hover:bg-[#ff1744] text-white">
                  <Mail size={20} />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Footer */}
      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-400 text-sm text-center md:text-left">
              © 2025 InvitasiKu. All rights reserved. Made with <Heart size={14} className="inline text-[#ff5722]" /> for your special moment.
            </p>
            <div className="flex gap-6 text-sm">
              <a href="#" className="text-gray-400 hover:text-[#ff5722] transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="text-gray-400 hover:text-[#ff5722] transition-colors">
                Terms of Service
              </a>
              <a href="#" className="text-gray-400 hover:text-[#ff5722] transition-colors">
                Cookie Policy
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
