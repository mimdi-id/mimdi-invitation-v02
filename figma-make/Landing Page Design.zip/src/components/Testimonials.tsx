import { Card, CardContent } from './ui/card';
import { Star, Quote } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { motion } from 'motion/react';

export function Testimonials() {
  const testimonials = [
    {
      name: 'Andi & Siti',
      role: 'Pernikahan 15 Januari 2025',
      image: 'https://api.dicebear.com/7.x/avataaars/svg?seed=andi',
      rating: 5,
      text: 'Undangan digital dari InvitasiKu sangat membantu! Tampilannya elegan, fiturnya lengkap, dan yang paling penting tamu-tamu kami mudah mengakses. Terima kasih sudah membuat hari spesial kami lebih berkesan! 💕'
    },
    {
      name: 'Budi & Rina',
      role: 'Pernikahan 8 Februari 2025',
      image: 'https://api.dicebear.com/7.x/avataaars/svg?seed=budi',
      rating: 5,
      text: 'Pelayanan cepat dan responsif! Undangan siap dalam sehari setelah kami kirim data. Tema yang kami pilih sangat cantik dan sesuai dengan konsep pernikahan kami. Highly recommended! 🌟'
    },
    {
      name: 'Dimas & Maya',
      role: 'Pernikahan 20 Maret 2025',
      image: 'https://api.dicebear.com/7.x/avataaars/svg?seed=dimas',
      rating: 5,
      text: 'Harga terjangkau dengan kualitas premium! Fitur RSVP dan ucapan sangat membantu kami untuk mengatur acara. Admin juga sabar banget ngebantu revisi sampai sempurna. Top deh! 👍'
    },
    {
      name: 'Eka & Devi',
      role: 'Pernikahan 5 April 2025',
      image: 'https://api.dicebear.com/7.x/avataaars/svg?seed=eka',
      rating: 5,
      text: 'Kami sangat puas dengan hasilnya! Undangan digitalnya interaktif, musicnya auto play, dan galeri fotonya cantik banget. Tamu-tamu juga pada komplen bagus undangannya. Thanks InvitasiKu! ❤️'
    },
    {
      name: 'Fajar & Lina',
      role: 'Pernikahan 12 Mei 2025',
      image: 'https://api.dicebear.com/7.x/avataaars/svg?seed=fajar',
      rating: 5,
      text: 'Prosesnya mudah dan praktis. Kami pilih tema, kirim data, transfer, langsung jadi! Hasilnya lebih dari ekspektasi. Animasinya smooth dan loadingnya cepat. Pokoknya the best! 🎉'
    },
    {
      name: 'Gita & Reza',
      role: 'Pernikahan 28 Juni 2025',
      image: 'https://api.dicebear.com/7.x/avataaars/svg?seed=gita',
      rating: 5,
      text: 'Undangan digital ini jadi solusi terbaik untuk kami yang ingin ramah lingkungan. Desainnya modern, fiturnya canggih, dan yang pasti hemat biaya cetak. Semua tamu bisa akses dengan mudah! 🌿'
    }
  ];

  return (
    <section id="testimonials" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
        >
          <span className="text-[#ff5722] mb-4 block">Testimoni</span>
          <h2 className="mb-4">Apa Kata Mereka?</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Ribuan pasangan telah mempercayai kami untuk momen spesial mereka
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ 
                duration: 0.5, 
                delay: index * 0.1,
                ease: [0.25, 0.1, 0.25, 1]
              }}
            >
              <Card 
                className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300 bg-gradient-to-br from-white to-gray-50 h-full"
              >
              <CardContent className="p-6">
                {/* Quote Icon */}
                <Quote className="text-[#ff5722]/20 mb-4" size={40} />

                {/* Rating */}
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star 
                      key={i} 
                      className="fill-[#ff5722] text-[#ff5722]" 
                      size={16} 
                    />
                  ))}
                </div>

                {/* Testimonial Text */}
                <p className="text-gray-700 mb-6 leading-relaxed">
                  "{testimonial.text}"
                </p>

                {/* User Info */}
                <div className="flex items-center gap-4 pt-4 border-t border-gray-200">
                  <Avatar>
                    <AvatarImage src={testimonial.image} alt={testimonial.name} />
                    <AvatarFallback>{testimonial.name.split(' ')[0][0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="text-gray-900">{testimonial.name}</div>
                    <div className="text-sm text-gray-500">{testimonial.role}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            </motion.div>
          ))}
        </div>

        {/* Trust Indicators */}
        <motion.div 
          className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <div>
            <div className="text-3xl mb-2" style={{ color: '#ff5722' }}>5000+</div>
            <div className="text-gray-600">Pasangan Puas</div>
          </div>
          <div>
            <div className="text-3xl mb-2" style={{ color: '#ff5722' }}>4.9/5</div>
            <div className="text-gray-600">Rating Google</div>
          </div>
          <div>
            <div className="text-3xl mb-2" style={{ color: '#ff5722' }}>98%</div>
            <div className="text-gray-600">Repeat Order</div>
          </div>
          <div>
            <div className="text-3xl mb-2" style={{ color: '#ff5722' }}>24/7</div>
            <div className="text-gray-600">Fast Response</div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
