import { Instagram, Facebook, Music, Pin, ScrollText, MessageCircle, Package, MessageSquare } from 'lucide-react';
import { useState } from 'react';
import { Button } from './components/ui/button';
import { Avatar, AvatarFallback } from './components/ui/avatar';

type ThemeType = 'default' | 'orange' | 'purple' | 'blue' | 'green';

export default function App() {
  const [activeTheme, setActiveTheme] = useState<ThemeType>('default');
  const [hoveredTheme, setHoveredTheme] = useState<ThemeType | null>(null);

  const menuItems = [
    {
      title: 'Undangan Digital',
      icon: ScrollText,
      gradient: 'from-orange-500 to-amber-500',
      href: '#undangan-digital',
      theme: 'orange' as ThemeType,
    },
    {
      title: 'Ucapan Digital',
      icon: MessageCircle,
      gradient: 'from-purple-500 to-violet-500',
      href: '#ucapan-digital',
      theme: 'purple' as ThemeType,
    },
    {
      title: 'Undangan Fisik',
      icon: Package,
      gradient: 'from-blue-500 to-cyan-500',
      href: '#undangan-fisik',
      theme: 'blue' as ThemeType,
    },
    {
      title: 'Hubungi Kami',
      icon: MessageSquare,
      gradient: 'from-green-500 to-emerald-500',
      href: 'https://wa.me/6281234567890',
      theme: 'green' as ThemeType,
    },
  ];

  const socialLinks = [
    { icon: Instagram, href: 'https://www.instagram.com/mimdi.id/', label: 'Instagram' },
    { icon: Facebook, href: 'https://www.facebook.com/mimdi.id/', label: 'Facebook' },
    { icon: Music, href: 'https://www.tiktok.com/@mimdi.id', label: 'TikTok' },
    { icon: Pin, href: 'https://id.pinterest.com/mimdidesign/', label: 'Pinterest' },
  ];

  const getBackgroundGradient = () => {
    const theme = hoveredTheme || activeTheme;
    switch (theme) {
      case 'orange':
        return 'from-orange-900/30 via-black to-amber-900/30';
      case 'purple':
        return 'from-purple-900/30 via-black to-violet-900/30';
      case 'blue':
        return 'from-blue-900/30 via-black to-cyan-900/30';
      case 'green':
        return 'from-green-900/30 via-black to-emerald-900/30';
      default:
        return 'from-purple-900/20 via-black to-pink-900/20';
    }
  };

  const getRadialGradient = () => {
    const theme = hoveredTheme || activeTheme;
    const intensity = hoveredTheme ? 0.6 : (activeTheme === 'default' ? 0.1 : 0.15);
    
    switch (theme) {
      case 'orange':
        return `bg-[radial-gradient(circle_at_50%_50%,rgba(251,146,60,${intensity}),transparent_50%)]`;
      case 'purple':
        return `bg-[radial-gradient(circle_at_50%_50%,rgba(139,92,246,${intensity}),transparent_50%)]`;
      case 'blue':
        return `bg-[radial-gradient(circle_at_50%_50%,rgba(59,130,246,${intensity}),transparent_50%)]`;
      case 'green':
        return `bg-[radial-gradient(circle_at_50%_50%,rgba(34,197,94,${intensity}),transparent_50%)]`;
      default:
        return `bg-[radial-gradient(circle_at_50%_50%,rgba(139,92,246,${intensity}),transparent_50%)]`;
    }
  };

  return (
    <div className="min-h-screen bg-black text-white relative overflow-hidden">
      {/* Background effects */}
      <div className={`absolute inset-0 bg-gradient-to-br ${getBackgroundGradient()} transition-all duration-700`} />
      <div className={`absolute inset-0 ${getRadialGradient()} transition-all duration-700`} />
      
      <div className="relative z-10 container mx-auto px-4 py-12 max-w-xl">
        {/* Header */}
        <div className="text-center mb-8 space-y-4">
          {/* Avatar */}
          <div className="flex justify-center mb-4">
            <Avatar className="h-24 w-24 border-4 border-purple-500/30 shadow-lg shadow-purple-500/20">
              <AvatarFallback className="bg-gradient-to-br from-purple-600 to-pink-600 text-white text-2xl">
                M
              </AvatarFallback>
            </Avatar>
          </div>
          
          <div className="inline-block">
            <h1 className="text-4xl mb-2 text-white">
              Mimdi
            </h1>
          </div>
          
          <div className="space-y-2">
            <p className="text-sm text-gray-500">Berbagi momen bersama kami</p>
            <div className="flex flex-wrap justify-center gap-2 text-xs">
              <span className="text-white">#PABRIKIDE</span>
              <span className="text-white">#MADEBYMIMDI</span>
            </div>
          </div>
        </div>

        {/* Social Media Icons */}
        <div className="flex justify-center gap-3 mb-10">
          {socialLinks.map((social) => (
            <a
              key={social.label}
              href={social.href}
              target="_blank"
              rel="noopener noreferrer"
              className="h-12 w-12 rounded-full border border-gray-700 bg-black/50 backdrop-blur-sm hover:bg-purple-600/20 hover:border-purple-500 transition-all duration-300 hover:scale-110 flex items-center justify-center"
              aria-label={social.label}
            >
              <social.icon className="h-5 w-5" />
            </a>
          ))}
        </div>

        {/* Menu Items */}
        <div className="space-y-4 mb-12">
          {menuItems.map((item, index) => (
            <a
              key={index}
              href={item.href}
              onClick={(e) => {
                if (item.href.startsWith('#')) {
                  e.preventDefault();
                  setActiveTheme(item.theme);
                }
              }}
              onMouseEnter={() => setHoveredTheme(item.theme)}
              onMouseLeave={() => setHoveredTheme(null)}
              target={item.href.startsWith('http') ? '_blank' : undefined}
              rel={item.href.startsWith('http') ? 'noopener noreferrer' : undefined}
              className="group w-full block relative overflow-hidden rounded-2xl bg-white hover:bg-gradient-to-r transition-all duration-300 hover:scale-[1.02] cursor-pointer p-5 shadow-lg"
              style={{
                ['--hover-gradient' as string]: `linear-gradient(to right, var(--tw-gradient-stops))`,
              }}
            >
              <div className={`absolute inset-0 bg-gradient-to-r ${item.gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-300`} />
              <div className="relative flex items-center justify-center">
                <div className="absolute left-0 bg-gray-100 group-hover:bg-black/20 rounded-xl p-2.5 transition-all duration-300">
                  <item.icon className="h-5 w-5 text-gray-700 group-hover:text-white transition-colors duration-300" />
                </div>
                <h3 className="text-black group-hover:text-white transition-colors duration-300">{item.title}</h3>
              </div>
            </a>
          ))}
        </div>

        {/* Footer */}
        <footer className="text-center text-sm text-gray-500 space-y-2">
          <p>dibuat dengan riang 🥰 bersama☕</p>
          <p>@ 2025 @ mimdi.id</p>
        </footer>
      </div>

      <style>{`
        @keyframes gradient {
          0%, 100% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
        }
        .animate-gradient {
          background-size: 200% auto;
          animation: gradient 3s ease infinite;
        }
      `}</style>
    </div>
  );
}
